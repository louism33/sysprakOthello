a university project - client to play reversi / othello
=======
# Alex the Friendly AI
Course project for System Praktikum, Winter Semester 2019 / 2020 at the LMU <br>
<br>
Reversi client and AI. <br>
<br>

`make test` to run tests

`make perft DEPTH=(depth)` to run get perft results to depth

Written by : 

    Zhenhan Gao
    Yufan Lu
    Marlene Eder
    Louis Mackenzie-Smith

