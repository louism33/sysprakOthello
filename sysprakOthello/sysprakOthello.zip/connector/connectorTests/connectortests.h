//
// Created by Bianca on 24/11/19.
//

#ifndef SYSPRAKOTHELLO_CONNECTORTESTS_H
#define SYSPRAKOTHELLO_CONNECTORTESTS_H

int testConvertMove();

#endif //SYSPRAKOTHELLO_CONNECTORTESTS_H
