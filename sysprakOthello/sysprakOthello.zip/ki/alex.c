//
// Created by louis on 11/25/19.
//

#include "alex.h"



int getBestMove(BOARD_STRUCT* boardStruct, int moveTime){

    return -1;
}