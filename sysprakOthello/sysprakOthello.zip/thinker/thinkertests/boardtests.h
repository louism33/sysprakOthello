//
// Created by louis on 11/23/19.
//

#ifndef SYSPRAKOTHELLO_BOARDTESTS_H
#define SYSPRAKOTHELLO_BOARDTESTS_H

int basicTests();
int fullTestSuite();

#endif //SYSPRAKOTHELLO_BOARDTESTS_H
