//
// Created by louis on 11/27/19.
//

#ifndef SYSPRAKOTHELLO_BOARDTESTS2_H
#define SYSPRAKOTHELLO_BOARDTESTS2_H



int fullTestSuiteBoard2();


#endif //SYSPRAKOTHELLO_BOARDTESTS2_H
