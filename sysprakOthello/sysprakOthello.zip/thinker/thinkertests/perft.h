//
// Created by louis on 11/30/19.
//

#ifndef SYSPRAKOTHELLO_PERFT_H
#define SYSPRAKOTHELLO_PERFT_H

int perftSuite();

int fromCommandLine(int depth);

#endif //SYSPRAKOTHELLO_PERFT_H
