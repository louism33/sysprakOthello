//
// Created by louis on 11/30/19.
//

#ifndef SYSPRAKOTHELLO_UNMAKEMOVETEST_H
#define SYSPRAKOTHELLO_UNMAKEMOVETEST_H


int fullTestSuiteUnmakeMoveTests();



#endif //SYSPRAKOTHELLO_UNMAKEMOVETEST_H
